"""
    MongoDB storage
"""

from .migrations import MongoMigrationSet
from .storage import MongoStorage
