"""
    Exposed classes and methods
"""

from .storage import FileStorage
