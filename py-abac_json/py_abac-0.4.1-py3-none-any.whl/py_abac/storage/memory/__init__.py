"""
    In-Memory storage
"""
from .storage import MemoryStorage
