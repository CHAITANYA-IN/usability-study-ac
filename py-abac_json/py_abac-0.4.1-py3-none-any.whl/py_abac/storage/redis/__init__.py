"""
    Exposed classes and methods
"""

from .storage import RedisStorage
