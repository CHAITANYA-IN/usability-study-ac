"""
    Logic conditions
"""

from .not_ import Not
from .all_of import AllOf
from .any_of import AnyOf
