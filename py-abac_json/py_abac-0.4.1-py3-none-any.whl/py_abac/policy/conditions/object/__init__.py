"""
    Object conditions
"""

from .equals_object import EqualsObject
