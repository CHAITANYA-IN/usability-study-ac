import ipaddress
import logging

from marshmallow import Schema, fields, post_load

from ..attribute.base import AttributeCondition, AttributeConditionSchema

LOG = logging.getLogger(__name__)

class InIPRangeAttribute(AttributeCondition):
    """
        Condition for IP address in any of a list of IP ranges or CIDR ranges,
        where the list is fetched from another ACE's attribute (attribute-to-attribute).
    """

    def _is_satisfied(self, ip_str) -> bool:
        """
            Checks if the given IP address is in any of the specified ranges or CIDRs.
            self.value is set by AttributeCondition.is_satisfied() to the fetched attribute.
        """
        ip_ranges = self.value
        # Normalize input to a list of entries (each entry is a CIDR string or [start_ip, end_ip])
        normalized = []
        if ip_ranges is None or ip_ranges == {} or ip_ranges == []:
            normalized = []
        elif isinstance(ip_ranges, str):
            normalized = [ip_ranges]
        elif isinstance(ip_ranges, list):
            if len(ip_ranges) == 2 and all(isinstance(v, str) for v in ip_ranges):
                normalized = [ip_ranges]
            else:
                for entry in ip_ranges:
                    if isinstance(entry, str):
                        normalized.append(entry)
                    elif isinstance(entry, list) and len(entry) == 2 and all(isinstance(v, str) for v in entry):
                        normalized.append(entry)
        else:
            normalized = []

        # If no IP range specified, allow all IPs
        if not normalized:
            return True

        if not isinstance(ip_str, str):
            LOG.debug(
                "Invalid type '%s' for attribute value. Condition not satisfied.",
                type(ip_str)
            )
            return False
        try:
            ip = ipaddress.ip_address(ip_str)
        except ValueError:
            return False

        for entry in normalized:
            if isinstance(entry, str): # CIDR string
                try:
                    net = ipaddress.ip_network(entry)
                    if ip in net:
                        return True
                except ValueError:
                    continue
            elif isinstance(entry, list) and len(entry) == 2: # [start_ip, end_ip] range
                try:
                    start = ipaddress.ip_address(entry[0])
                    end = ipaddress.ip_address(entry[1])
                    if start <= ip <= end:
                        return True
                except ValueError:
                    continue
        return False

class InIPRangeAttributeSchema(AttributeConditionSchema):
    """
        JSON schema for InIPRangeAttribute condition
    """

    @post_load
    def post_load(self, data, **_):
        return InIPRangeAttribute(**data)