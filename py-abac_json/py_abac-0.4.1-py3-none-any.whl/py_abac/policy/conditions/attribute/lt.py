"""
    Less than attribute condition
"""

import logging

from marshmallow import post_load

from .base import AttributeCondition, AttributeConditionSchema
from ..collection.base import is_collection

LOG = logging.getLogger(__name__)


class LtAttribute(AttributeCondition):
    """
        Condition for attribute value less than that of another
    """

    def _is_satisfied(self, what) -> bool:
        # Check if value is less than other value or collection
        try:
            if is_collection(self.value):
                if is_collection(what):
                    return max(what) < min(self.value)
                return what < min(self.value)
            return what < self.value
        except TypeError:
            LOG.debug(
                "Invalid type '%s' for attribute value at path '%s' for element '%s'."
                " Condition not satisfied.",
                type(self.value),
                self.path,
                self.ace
            )
            return False


class LtAttributeSchema(AttributeConditionSchema):
    """
        JSON schema for less than attribute condition
    """

    @post_load
    def post_load(self, data, **_):  # pylint: disable=missing-docstring,no-self-use
        return LtAttribute(**data)
