"""
    Condition for checking if IP address is in any of the listed IP ranges.
"""

import ipaddress
import logging

from marshmallow import Schema, fields, post_load

from ..base import ConditionBase

LOG = logging.getLogger(__name__)

class InIPRange(ConditionBase):
    """
        Condition for IP address in any of a list of IP ranges or CIDR ranges.
        value: list of [start_ip, end_ip] pairs, a single [start_ip, end_ip], or a CIDR string.
        If value is empty or not specified, all IPs are allowed.
    """

    def __init__(self, value):
        # Normalize input to a list of entries (each entry is a CIDR string or [start_ip, end_ip])
        self.value = []
        if value is None or value == {} or value == []:
            self.value = []
        elif isinstance(value, str):
            self.value = [value]
        elif isinstance(value, list):
            # Single [start_ip, end_ip]
            if len(value) == 2 and all(isinstance(v, str) for v in value):
                self.value = [value]
            else:
                # List of CIDRs and/or [start_ip, end_ip]
                for entry in value:
                    if isinstance(entry, str):
                        self.value.append(entry)
                    elif isinstance(entry, list) and len(entry) == 2 and all(isinstance(v, str) for v in entry):
                        self.value.append(entry)
        else:
            # Fallback: treat as empty (allow all)
            self.value = []

    def is_satisfied(self, ctx) -> bool:
        # If no IP range specified, allow all IPs
        if not self.value:
            return True

        ip_str = ctx.attribute_value
        if not isinstance(ip_str, str):
            LOG.debug(
                "Invalid type '%s' for attribute value at path '%s' for element '%s'. Condition not satisfied.",
                type(ip_str), ctx.attribute_path, ctx.ace
            )
            return False
        return self._is_satisfied(ip_str)

    def _is_satisfied(self, ip_str) -> bool:
        """
            Checks if the given IP address is in any of the specified ranges or CIDRs.

            :param ip_str: IP address to check
            :return: True if satisfied else False
        """
        try:
            ip = ipaddress.ip_address(ip_str)
        except ValueError:
            return False

        for entry in self.value:
            # CIDR string
            if isinstance(entry, str):
                try:
                    net = ipaddress.ip_network(entry)
                    if ip in net:
                        return True
                except ValueError:
                    continue
            # [start_ip, end_ip] range
            elif isinstance(entry, list) and len(entry) == 2:
                try:
                    start = ipaddress.ip_address(entry[0])
                    end = ipaddress.ip_address(entry[1])
                    if start <= ip <= end:
                        return True
                except ValueError:
                    continue
        return False

class InIPRangeSchema(Schema):
    """
        JSON schema for InIPRange condition
    """
    value = fields.Raw(required=False, allow_none=True)  # Accepts list, list of lists, string, or dict

    @post_load
    def post_load(self, data, **_):
        return InIPRange(**data)
