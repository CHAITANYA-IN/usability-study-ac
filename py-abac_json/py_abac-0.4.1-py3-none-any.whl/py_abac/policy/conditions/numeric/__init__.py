"""
    Numeric conditions
"""

from .eq import Eq
from .gt import Gt
from .gte import Gte
from .lt import Lt
from .lte import Lte
from .neq import Neq
