"""
    Attribute providers
"""
