import os
from dotenv import load_dotenv
from pymongo import MongoClient

DEFAULT_MONGODB_HOST = "mongodb://mongo:password@127.0.0.1:27017"

load_dotenv("../../.env")
print("Connecting to MONGODB_HOST=", os.getenv("MONGODB_HOST"))

def create_client() -> MongoClient:
    host = os.getenv("MONGODB_HOST", DEFAULT_MONGODB_HOST)
    return MongoClient(host)
